#include <iostream>

int add (int * arr)
{


}
int main(int argc, char const *argv[])
{
    
    

    
    
    return 0;
}
